import torch
from torch import nn
from torch.nn import functional as F


class lenet5(nn.Module):

    def __init__(self):
        super(lenet5,self).__init__()

        self.conv_unit = nn.Sequential(
            nn.Conv2d(3,  #RGB
                      6,  #6中kernel 6种特征
                      kernel_size=5, #5*5卷积核
                      stride=1 ,#步进精度是1
                      padding=0
                      ),            ##图片先经过卷积层
            nn.AvgPool2d(kernel_size=2,#窗口2*2
                         stride=2,#  步进2
                         padding=0  #填充0
                        ),            #池化层
            nn.Conv2d(6,16, kernel_size=5, stride=1,padding=0),
            nn.AvgPool2d(kernel_size=2, stride=2, padding=0)
        )

        self.fc_unit= nn.Sequential(
            nn.Linear(400,120),        #全连接层 16*5*5
            nn.ReLU(),              #激活函数
            nn.Linear(120,84)  ,  #隐藏层的全连接层
            nn.ReLU(),
            nn.Linear(84,10)    #到输出层


        )

        #[b,3,32,32]   #测试下输出层维度  测试得到输出[2 16 5 5]两张图片，
        # tmp =torch.randn(2, 3, 32, 32) #两张图，RGB ,32*32 16 5 5是输入层，将输入层打平
        # out = self.conv_unit(tmp)
        # print('conv out', out.shape)
        # self.criteon = nn.CrossEntropyLoss()  # 包含了SOFMAX

    def forward(self, x):
        batchsz = x.size(0) #图片数量
        x = self.conv_unit(x)  #
        x = x.view(batchsz, 16*5*5) #打平 [b,16,5,5] ->[b,16*5*5]
        #[b, 16*5*5]=>[b, 10]
        logits = self.fc_unit(x) #输出结果为变成 0-1概率 解下来要输入SOFMAX
        #用交叉熵衡量误差 self.criteon表示LOSS评价标准
        #这里先不做这个变换

        return logits








def main():
    net= lenet5()
    tmp = torch.randn(2, 3, 32, 32)  # 两张图，RGB ,32*32 16 5 5是输入层，将输入层打平
    out = net(tmp)
    print('the net out', out.shape)

if __name__ == '__main__':
    main()